package dev.syscode.configurations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
